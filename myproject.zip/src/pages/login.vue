<template>
  <q-page class="bg-background-color:#012E57; window-height window-width row justify-center items-center">
    <div class="column">
      <div class="row">
        <h5 class="text-frutiger text-center text-bold text-white q-my-md">Login</h5>
      </div>
      <div class="row">
        <q-card square bordered class="q-pa-lg shadow-1">
          <q-card-section>
            <q-form class="q-gutter-md">
              <q-input square filled clearable class="text-frutiger" v-model="Number" type="number" label="Mobile-no" />
            </q-form>
          </q-card-section>
          <q-card-actions class="q-px-md">
            <q-btn unelevated style="background-color:#f0951f; " size="lg" class=" text- frutiger full-width text-white" label="Login" />
          </q-card-actions>
          <q-card-section class="text-center q-pa-none">
            <p class="text-frutiger text-grey-6">Not reigistered? <q-btn class=" text-frutiger text-blue" label="Sign Up" @click.native="redirect()" /></p>
          </q-card-section>
        </q-card>
      </div>
      <q-footer >
        <q-toolbar>
          <q-toolbar-title class="text-frutiger text-center">By Signing up,you agree to T&C</q-toolbar-title>
        </q-toolbar>
      </q-footer>
    </div>
  </q-page>
</template>

<script>
export default {
  name: 'Login',
  data () {
    return {
      Number: '',
    //   password: ''
    }
  },
  
method:{
      redirect()
    {
    window.location== "#/signup"
    }
    }


}

</script>


<style>
.q-card {
  width: 360px;
}
</style>